package klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalS211Application {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalS211Application.class, args);
	}

}
